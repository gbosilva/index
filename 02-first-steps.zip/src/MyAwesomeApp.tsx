
const fisrtName = 'Gabriel';
const lastName = 'Silva';
const favoriteGames = ['Elden Ring', 'Smash', 'Metal Gear'];
const isActive = true;
const address = {
    zipCode: 'ABC-123',
    country: 'Mexico',
}

export const MyAwesomeApp = () => {
    return(
        <>
            <h1>{fisrtName}</h1>
            <h3>{lastName}</h3>
            <p>{ favoriteGames.join(', ') }</p>
            <h1>{isActive ? 'Activo' : 'No Activo'}</h1>
            <p>
                { JSON.stringify(address) }
            </p>
        </>
    );
}