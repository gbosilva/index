import { useState } from 'react';
import './itemCounter.css';

interface Props {
    name: string;
    quantity?: number
}

export const ItemCounter = ( {name, quantity = 1}: Props ) => {

    // Hook que esta desestructurado del resultado del 
    // metodo useState el cual devuelve 2 objetos
    // que son count y setCount
    // setCount es una funcion que puede cambiar
    // el valor de count
    const [count, setCount] = useState(quantity);

    const handleAdd = () => {
        setCount(count+1);
    };
    const handleSubstract = () => {
        if(count === 1) return;
        setCount(count-1);
    };

    const handleClick = () => {
        console.log(`Click ${name}`)
    };
  return (
    <section className='item-row'>
        <span className='item-text'>{name}</span>
        <button 
        // onMouseEnter={ ()=>{console.log(`Mouse enter ${name}`)}}
        onClick={ handleAdd }>+</button>
        <span>{count}</span>
        <button onClick={ handleSubstract }>-</button>
    </section>
  );
};
