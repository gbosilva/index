import type { GiphyRandomResponse } from "./data/giphy.resonse";

const API_KEY = 'IWQBIOzfU18ATnj6UHx2nlZjEtQ6nklS';

const myRequest = fetch(`https://api.giphy.com/v1/gifs/random?api_key=${API_KEY}`);

/*
myRequest.then( (response) => response.json()
    // {
    // console.log(response);

    // response.json().then( (data) => {
    //     console.log(data);
    // });
// } 
).then( (datos) => {
    const imageURL = datos.data.images.original.url;
    console.log(imageURL);

    const imgElement = document.createElement('img');
    imgElement.src = imageURL;
    document.body.append(imgElement);
})
.catch( (err) => {
    console.log(err);
});

*/

/**
 * 
 * @param url Funcion para agregar una imagen al DOM
 */
const createImageIsideDOM = (url: string) => {
    const imgElement = document.createElement('img');
    imgElement.src = url;
    document.body.append(imgElement);
}

myRequest.then( (response) => response.json()
    ).then( ( {data} : GiphyRandomResponse) => {
    const imageURL = data.images.original.url;
    createImageIsideDOM(imageURL);
})
.catch( (err) => {
    console.log(err);
});