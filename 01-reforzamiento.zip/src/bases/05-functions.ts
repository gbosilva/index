
// Declaracion de funcion en javascripts
// La funcion infiere que va a devolver un string
// Para evitar que la funcion infiera el tipo a retornar
// le puedo poner :string y asi le digo que va a devolver un string
function greet(name:string):string{
    return `Hola ${name}`
}

const message = greet('Goku');

console.log(message);


// Funcion de flecha
const greet2 = (name:string) =>{
    return `Hola ${name}`
};

const message2 = greet2('Vegeta');

console.log(message2);

// Funcion normal
function getUser(): User{
    return {
        uid: 'ABC-123',
        username: 'El_Papi23',
    }
};

// Funcion de flecha
const getUser2 = () => {
    return {
        uid: 'ABC-123',
        username: 'El_Papi23',
    }
}

const user = getUser2();
console.log(user);

// Simplificar una funcion de flecha
const greet3 = (name:string) => `Hola ${name}`;
const message3 = greet('Gon');
console.log(message3);


// Simplificar Funcion de flecha
const getUser3 = () => (
    {
        uid: 'ABC-123',
        username: 'El_Papi23',
    }
)

const user3 = getUser3();
console.log(user3);


interface User{
    uid:string;
    username: string;
}


// Ejemplo de uso de funcion callback (funcion de flecha)

const myNumbers : number[] = [1,2,3,4,5];

myNumbers.forEach( (value)=> console.log({value}) );
myNumbers.forEach( console.log );