const firstName: string = 'Totem';
const lastName = 'Fox';

//Diferencia entre let y const
//let: para crear una variable que sabemos que si va a cambiar
//const: Para crear una constante, esto es una variable que sabemos que no va a cambiar y es mas lijero

//Type script permite tipar las variables
//Por eso el archivo se guarda como .ts
let diceNumber = 5;

console.log(firstName, lastName);

const containsLetterF = lastName.includes('f');
console.log({ containsLetterF, diceNumber });