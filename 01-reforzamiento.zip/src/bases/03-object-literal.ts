const ironman = {
    firstName: 'Tony',
    lastName: 'Stark',
    age: 45,
    address: {
        postalCode: 'ABC123',
        city: 'New York'
    }
};

// Con esto le decimos al sistema que spiderman
// apunta al mismo espacio de memoria que ironman
// es decir, que si uno cambia, el otro tambien
// Es como decirle que se vuelvan espejos
// const spiderman = ironman;

// Lo correcto es hacerlo con el operador spread
// Esto permite tener las variables separadas
// Pero esto solo funciona para que respete las properties
// que solo son variables, si hay algun otro objeto dentro
// ese no lo respeta
// const spiderman = {...ironman}

// Entonces la mejor forma de hacerlo es asi
const spiderman = structuredClone(ironman);

// Esto es posible porque el objeto person es una constante
// pero las variables si se pueden cambiar
spiderman.firstName = 'Peter';
spiderman.lastName = 'Parker';
spiderman.age = 22;
spiderman.address.city = 'San Jose';

console.log(ironman, spiderman);

// Una Interface es parecida a una clase y es propia de typescript,
// es decir, no existe en javascript y sirve para specificar
// un objeto para decirle de que tipo deben ser las propiedades
// Es un molde de como quiero que un objeto luzca.
interface Person{
    firstName: string;
    lastName: string;
    age: number;
    address?: Address;
}

interface Address {
    postalCode: string;
    city: string;
}

const wolverine: Person = {
    firstName: 'Logan',
    lastName: 'Mutante',
    age: 200,
};

console.log(wolverine);