
const firstName = 'Gabriel';
const lastName = 'O\'neal';

// El caracter backslash sirve para escapar un caracter
//especial que queremos que se muestre en pantalla

console.log(firstName, lastName);

// Para concatenar seria de la siguiente manera
console.log(` ${firstName} ${lastName} `);