
const myPromise = new Promise<number>( (resolve, reject) =>{
    setTimeout( ()=>{
        //Se debe cumplir la promesa
        resolve(100);
        // reject('No cumplio');
    }, 2000)
});

myPromise.then(
    (myMoney) => {
        console.log(`Tengo mi dinero $${myMoney} de vuelta`);
    }
).catch( reason => {
    console.log(reason);
}).finally( () => {
    console.log('Que la vida siga')
}
);