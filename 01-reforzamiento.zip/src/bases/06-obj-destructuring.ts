//Desestructuracion es desarmar un objeto y extraer sus propiedades

const person = {
    name: 'Tony',
    age: 45,
    key: 'Ironman'
};

// Aqui se va a desestructurar el objeto person
// No hace falta crear nuevas variables, asi ya se pueden usar
const {name: ironmanName, age, key} = person;

// const name = person.name;
// const age = person.age;
// const key = person.key;

console.log( {ironmanName, age, key} );

interface Hero{
    name: string;
    age: number;
    key: string;
    rank?: string;
}

const useContext = ( { key, name, age, rank = 'Sin rango' }: Hero ) => {
// const useContext = ( props: Hero ) => {
    // const {key, name, age, rank} = props;
    return {
        keyName: key,
        user: {
            name,
            age: age,
        },
        rank: rank,
    }
}

// const context = useContext(person);
const { rank, keyName, user: { name } } = useContext(person);
console.log({ rank, keyName, name });

