import type { GiphyRandomResponse } from "./data/giphy.resonse";

const API_KEY = 'IWQBIOzfU18ATnj6UHx2nlZjEtQ6nklS';

/**
 * 
 * @param url Funcion para agregar una imagen al DOM
 */
const createImageIsideDOM = (url: string) => {
    const imgElement = document.createElement('img');
    imgElement.src = url;
    document.body.append(imgElement);
};

//Async and Await
/**
 * Funcion asincrona para extraer la url de la imagen
 * @returns 
 */
const getRandomGifUrl = async (): Promise<string> => {
    const response = await fetch(`https://api.giphy.com/v1/gifs/random?api_key=${API_KEY}`);

    const { data } = ( await response.json() ) as GiphyRandomResponse;

    return data.images.original.url;
};

// getRandomGifUrl().then( (url) => createImageIsideDOM(url) );
getRandomGifUrl().then(createImageIsideDOM);