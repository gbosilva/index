
// Tratar de evitar este tipo de declaraciones de arreglo
// const myArray = [1,2,3,4, true, {}];

// Arreglo de numeros
// Typescript infiere que como la mayoria de los elementos
// del array son numeros entonces es un array de numeros
const myArray = [1,2,3,4,5];

myArray.push(20);

console.log(myArray);

for(const myNumber of myArray) {
    console.log(myNumber +10 );
}

// Apuntar a la misma referencia
// Si uno cambia, el otro tambien
const myArray2 = myArray;

//Usarlo asi mejor
const myArray3 = structuredClone(myArray);