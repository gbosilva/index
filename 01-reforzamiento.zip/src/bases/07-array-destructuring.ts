
const characterNames = ['Goku', 'Vegeta', 'Trunks'];

// Desestructuracion de arreglos, aqui si importa el orden
// const [ p1 , p2, p3 ] = characterNames;
// console.log({ p1, p2, p3 });

//Asi se desestructura solo un elemento, respetando los demas
const [  , , p3 ] = characterNames;
console.log({ p3 });

// Funcion que devuelve un arreglo de objetos
const returnsArrayFn = () => {
    // El as const le dice a typescript que la funcion siempre 
    // va a regresar primero un string y luego un number
    return ['ABC', 123] as const
};

// Esto va a desestructurar el arreglo
// En arreglos desestructurados, el orden siempre importa
// letter siempre sera un string y 
// numbers siempre seran numeros
const [ letters, numbers ] = returnsArrayFn();

console.log(letters + 100);


//-------------------------------------- TAREA

const useState = (value: string) => {
    return [value, (newValue: string) => {console.log({ newValue })} ] as const
};

const [ name, setName ] = useState('Goku');
console.log({ name });
setName('Vegeta');